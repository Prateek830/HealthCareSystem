import { Component, OnInit } from '@angular/core';
import { RegistrationService } from '../Services/registration.service';
import { User } from '../User/user';

@Component({
  selector: 'app-view-user',
  templateUrl: './view-user.component.html',
  styleUrls: ['./view-user.component.css']
})
export class ViewUserComponent implements OnInit {
user:User[]=[];

updateDiv:boolean=false; 
  msg:string;
  errorMsg:string;
  constructor(private viewService:RegistrationService) { }

  ngOnInit(): void {
    this.viewService.viewUser().subscribe(data=>this.user=data);
    console.log(this.user);;
  }

  deleteUser(userId:number){

    if(confirm("Confirm Deletion of User Id:"+userId)){
      this.viewService.deleteUserFromRemote(userId)
      .subscribe(data=>{
        this.msg=data;
        this.errorMsg=undefined;
        
        this.viewService.viewUser().subscribe(data=>this.user=data);
        console.log(this.user);
      },
        error=>{
          this.errorMsg=error.error;
          this.msg=undefined;
        });


}
  }
}
