import { Component, OnInit } from '@angular/core';
import { User } from '../User/user';
import { RegistrationService } from '../Services/registration.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  user:User=new User();
  msg:String;
  errorMsg:String;

  constructor(private registerservice:RegistrationService,private _route:Router) { }

  ngOnInit(): void {
  }

  registerUser(){
    this.registerservice.registerUserFromRemote(this.user).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.user=new User()
      console.log("Registration Successful");
      this._route.navigate(['/login']);
    },

      error=>{this.errorMsg=error.error;   
      console.log(error.error);
      this.msg=undefined});
  } 

}
