import { Injectable } from '@angular/core';
import { User } from '../User/user';
import { Observable } from 'rxjs';
import {HttpClient} from '@angular/common/http';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService implements CanActivate{

  constructor(private http:HttpClient,private router:Router) { }

  public loginUser(user:User):Observable<any>{
    console.log("Login:"+JSON.stringify(user));
    localStorage.setItem("token",JSON.stringify(user));
    return this.http.post("http://localhost:6566/login",user,{responseType:'text'});
  }

  public registerUserFromRemote(user:User):Observable<any>{
    return this.http.post("http://localhost:6566/signup",user,{responseType:'text'});
  }

  public viewUser():Observable<any>{
    return this.http.get("http://localhost:6566/viewAllUser");
  } 

  public adminLogin(user:User):Observable<any>{
    console.log("Login:"+JSON.stringify(user));
    localStorage.setItem("token",JSON.stringify(user));
    return this.http.post("http://localhost:6566/admin",user,{responseType:'text'});
  }

  public deleteUserFromRemote(userId:number):Observable<any>{

    return this.http.delete("http://localhost:6566/deleteuser/"+userId,{responseType:'text'});
  }

 /* logout():Observable<any> { console.log("inside service delete"); 
  return this.http.get("http://localhost:6566/user/logout/"); }

 */

canActivate(): boolean  {
  if(localStorage.getItem("token"))
      return true;
  else 
  {
    this.router.navigateByUrl("error");
    return false;
  }
    
}
/* loginUser(user:User){
  console.log("Login:"+JSON.stringify(user));
  localStorage.setItem("token",JSON.stringify(user));
} */
logOut(){
  console.log("LogOut");
localStorage.removeItem("token");
}

}