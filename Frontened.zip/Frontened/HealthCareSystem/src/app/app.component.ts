import { Component } from '@angular/core';
import { RegistrationService } from './Services/registration.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'HealthCareSystem';

  constructor(private loginService:RegistrationService){}

  logout()
  {
    this.loginService.logOut();
  }

}
