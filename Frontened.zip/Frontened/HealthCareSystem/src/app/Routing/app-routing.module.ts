import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {LoginComponent} from '../login/login.component';
import { LoginsuccessComponent } from '../loginsuccess/loginsuccess.component';
import { RegistrationComponent } from '../registration/registration.component';
import { ViewUserComponent } from '../view-user/view-user.component';
import { AdminComponent } from '../admin/admin.component';
import { HomeComponent } from '../home/home.component';
import { ErrorComponent } from '../error/error.component';
import { RegistrationService } from '../Services/registration.service';




const routes: Routes = [
  {path:'login',component:LoginComponent},
  {path:'loginsuccess',component:LoginsuccessComponent},
  {path:'register',component:RegistrationComponent},
  {path:'viewUser',component:ViewUserComponent,canActivate:[RegistrationService]},
  {path:'admin',component:AdminComponent},
  {path:'home',component:HomeComponent},
  {path:'error',component:ErrorComponent},
  
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
