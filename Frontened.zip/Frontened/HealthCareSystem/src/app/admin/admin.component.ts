import { Component, OnInit } from '@angular/core';
import { RegistrationService } from '../Services/registration.service';
import { User } from '../User/user';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  user:User=new User();
  msg:String='';
  errorMsg:String;

  constructor(private adminService:RegistrationService,private _route:Router) { }

  ngOnInit(): void {
  }

  admin(){
    this.adminService.adminLogin(this.user).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.user=new User();
      this._route.navigate(['/viewUser']);
    },

      error=>{this.errorMsg=error.error; 
      console.log(error.error);
      this.msg=undefined}); 
}


}